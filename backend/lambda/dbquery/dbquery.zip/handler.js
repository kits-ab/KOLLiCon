"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const mysql = __importStar(require("mysql2/promise"));
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    // Initialize AWS Secrets Manager client
    const secretsManagerClient = new client_secrets_manager_1.SecretsManagerClient({ region: 'eu-west-1' });
    // Retrieve DB secret ARN from environment variable
    const secretArn = process.env.DB_SECRET_ARN;
    if (!secretArn) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: 'DB_SECRET_ARN environment variable not set' }),
        };
    }
    // Get secret from AWS Secrets Manager
    try {
        const getSecretValueCommand = new client_secrets_manager_1.GetSecretValueCommand({ SecretId: secretArn });
        const secretValue = yield secretsManagerClient.send(getSecretValueCommand);
        const secretString = secretValue.SecretString;
        if (!secretString) {
            return {
                statusCode: 500,
                body: JSON.stringify({ error: 'Secret string is nil' }),
            };
        }
        // Parse the secret string to get DB credentials
        const secret = JSON.parse(secretString);
        // Database connection string
        const connConfig = {
            host: secret.host,
            user: secret.username,
            password: secret.password,
            database: secret.engine, // Assuming the database name is 'postgres'
            port: secret.port,
            ssl: {
                rejectUnauthorized: false,
            },
        };
        // Create a new database connection
        const connection = yield mysql.createConnection(connConfig);
        // Get SQL query from queryString parameters of the event
        const sqlQuery = (_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.sql;
        if (!sqlQuery) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'No SQL query provided in the query string' }),
            };
        }
        // Execute the query
        const [rows] = yield connection.execute(sqlQuery);
        // Close the connection
        yield connection.end();
        return {
            statusCode: 200,
            body: JSON.stringify({ data: rows }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: `Database or AWS Secrets Manager error: ${error.message}` }),
        };
    }
});
exports.handler = handler;
